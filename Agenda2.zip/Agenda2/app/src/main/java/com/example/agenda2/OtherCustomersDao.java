package com.example.agenda2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.agenda2.Models.OtherCustomersModel;

import java.util.List;
@Dao
public interface OtherCustomersDao {

    @Insert
    Void insert(OtherCustomersModel... u);

    @Query("SELECT CustomerName FROM OtherCustomersModel")
    List<String> getAll();

    @Query("Delete From OtherCustomersModel Where CustomerName = :name")
    void deleteRow(String name);

    @Update
    Void update(OtherCustomersModel otherModel);

    @Delete
    Void delete(OtherCustomersModel otherModel);

}