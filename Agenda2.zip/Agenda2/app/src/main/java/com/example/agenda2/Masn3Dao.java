package com.example.agenda2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.agenda2.Models.Masn3Model;

import java.util.List;

@Dao
public interface Masn3Dao {

    @Insert
    Void insert (Masn3Model... u);

    @Query("SELECT * FROM Masn3Model Where Type == :type")
    List<Masn3Model> getMasn3Customers(String type);

    @Update
    Void update(Masn3Model customerModel);

    @Delete
    Void delete(Masn3Model customerModel);
}
